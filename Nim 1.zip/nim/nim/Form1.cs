﻿using System.Diagnostics;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace nim
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        private int columnCount;

        private int[] Columns;
        private int[] BaseColumns;

        private int RowCount = 0;
        private bool playerOne = false;
        private int[] toRemove = [2];

        private System.Windows.Forms.Timer simpleTimer;
        private System.Windows.Forms.Timer think;
        private bool blink = false;
        private bool pauseMoves = false;

        private int[,] moves;
        private int curIndex = 0;

        public bool usesAI = false;
        private bool isGameLog = false;
        public int AIStrength = 0;

        public Form1()
        {
            InitializeComponent();

            Random random = new();
            columnCount = random.Next(5, 8);
            Columns = new int[columnCount];
            BaseColumns = new int[columnCount];

            for (int i = 0; i < columnCount; i++)
            {
                int value = random.Next(3, 8);
                Columns[i] = value;
                BaseColumns[i] = value;
                RowCount = Math.Max(RowCount, Columns[i]);
            }

            NextTurn();
            xBox.Maximum = Columns.Length - 1;
            amountBox.Maximum = RowCount;

            think = new System.Windows.Forms.Timer();
            think.Interval = 200;
            think.Tick += think_event;
            think.Start();

            simpleTimer = new System.Windows.Forms.Timer();
            simpleTimer.Interval = 1000;
            simpleTimer.Tick += FinishDeleting;

            moves = new int[RowCount * Columns.Length, 2];
        }

        string[] lines = System.IO.File.Exists(@"output-file.txt") ? System.IO.File.ReadAllLines(@"output-file.txt") : [];
        public void setupBlock(int startInt)
        {
            columnCount = int.Parse(lines[startInt + 2]);
            Columns = new int[columnCount];
            BaseColumns = new int[columnCount];

            string[] fileColumns = lines[startInt + 3].Split(' ');

            string[] playerAndAi = lines[startInt + 1].Split(' ');

            for (int i = 0; i < columnCount; i++)
            {
                int value = int.Parse(fileColumns[i]);
                Columns[i] = value;
                BaseColumns[i] = value;
                RowCount = Math.Max(RowCount, Columns[i]);
            }

            moves = new int[RowCount * Columns.Length, 2];
            int moveCount = int.Parse(lines[startInt + 4]);
            for (int i = 0; i < moveCount; i++)
            {
                string[] values = lines[startInt + 4 + (i + 1)].Split(' ');
                moves[i, 0] = int.Parse(values[1]);
                moves[i, 1] = int.Parse(values[2]);
            }

            playerOne = true;
            isGameLog = true;
            usesAI = bool.Parse(playerAndAi[1]);

            if (usesAI)
            {
                PlayerLabel.Text = "Your Turn";
            }

            xBox.Visible = false;
            amountBox.Visible = false;
            actionButton.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            Next.Visible = true;
            Back.Visible = true;

            DisplayBlock();
        }

        private void DisplayBlock()
        {
            blink = !blink;

            string Text = "Y\n\n";
            for (int row = RowCount; row > 0; row--)
            {
                Text = Text + (row) + " ";
                for (int col = 0; col < Columns.Length; col++)
                {
                    if (Columns[col] < row)
                    {
                        Text = Text + "   " + " ";
                    }
                    else if (toRemove[0] == col && blink && row > Columns[col] - toRemove[1])
                    {
                        Text = Text + "   " + " ";
                    }
                    else
                    {
                        Text = Text + "***" + " ";
                    }
                }

                Text = Text + "\n";
            }

            Text = Text + "  ";
            for (int col = 0; col < Columns.Length; col++)
            {
                Text = Text + " " + col + "  ";
            }
            Text = Text + "  X";

            box.Text = Text;
        }

        private (int column, int toRemove) GetBestMove() {
            int xorSUM = 0;
            for (int i = 0; i < Columns.Length; i++)
            {
                xorSUM = xorSUM ^ Columns[i];
            }

            for (int i = 0; i < Columns.Length; i++)
            {
                int target = Columns[i] ^ xorSUM;
                if (target < Columns[i])
                {
                    return (i, Columns[i] - target);
                }
            }

            return GetMove();
        }

        private (int column, int toRemove) GetMove()
        {
            int index = random.Next(0, columnCount);

            while (Columns[index] == 0)
            {
                index = (int)Math.Floor(random.NextDouble() * Columns.Length);
            }

            int height = random.Next(1, Columns[index] + 1);
            return (index, height);
        }

        private void NextTurn()
        {
            toRemove = [-1, -1];
            pauseMoves = false;

            playerOne = curIndex % 2 == 0 ? true : false;
            DisplayBlock();
            PlayerLabel.Text = $"Player {(playerOne ? "one" : "two")} turn";
            if (usesAI && !playerOne)
            {
                PlayerLabel.Text = $"AI's turn!";
            } else if (usesAI && playerOne)
            {
                PlayerLabel.Text = "Your Turn";
            }

            if (usesAI && !playerOne && !isGameLog)
            {
                pauseMoves = true;
                (int col, int removeAmount) = (0, 0);
                if (AIStrength == 2)
                {
                    (col, removeAmount) = GetBestMove();
                } else if (AIStrength == 1) {
                    if (random.Next(0, 1) < 0.7)
                    {
                        (col, removeAmount) = GetBestMove();
                    } else
                    {
                        (col, removeAmount) = GetMove();
                    }
                } else
                {
                    (col, removeAmount) = GetMove();
                }

                toRemove = [col, removeAmount];

                simpleTimer = new System.Windows.Forms.Timer();
                simpleTimer.Interval = 1000;
                simpleTimer.Tick += FinishDeleting;
                simpleTimer.Start();
            }
        }

        private void think_event(object sender, EventArgs e)
        {
            if (toRemove[0] == -1)
            {
                return;
            }

            DisplayBlock();
        }

        private void actionButton_Click(object sender, EventArgs e)
        {
            ErrorBox.Text = "";
            if (pauseMoves)
            {
                return;
            }

            if ((int)xBox.Value >= columnCount || Columns[(int)xBox.Value] < amountBox.Value || (int)amountBox.Value == 0)
            {
                ErrorBox.Text = "Illegal Move";
                return;
            }

            toRemove = [(int)xBox.Value, (int)amountBox.Value];
            pauseMoves = true;

            simpleTimer = new System.Windows.Forms.Timer();
            simpleTimer.Interval = 1000;
            simpleTimer.Tick += FinishDeleting;
            simpleTimer.Start();
        }

        private void FinishDeleting(object sender, EventArgs e)
        {
            simpleTimer.Stop();
            Columns[toRemove[0]] -= toRemove[1];

            if (!isGameLog)
            {
                moves[curIndex, 0] = toRemove[0];
                moves[curIndex, 1] = toRemove[1];
                curIndex = curIndex + 1;
            }

            bool hasWon = true;
            foreach (int amountLeft in Columns)
            {
                if (amountLeft > 0)
                {
                    hasWon = false;
                    break;
                }
            }

            if (hasWon)
            {
                if (isGameLog)
                {
                    pauseMoves = false;
                    PlayerLabel.Text = $"Player {(playerOne ? "one" : "two")} has won!";
                    if (usesAI && !playerOne)
                    {
                        PlayerLabel.Text = $"AI has won!";
                    }
                    return;
                }
                Debug.WriteLine("this path");

                string[] lines = System.IO.File.ReadAllLines(@"output-file.txt");
                string filePath = Directory.GetCurrentDirectory();

                filePath = Path.Combine(filePath, "output-file.txt");
                StreamWriter streamWriter = new StreamWriter(filePath, true);

                streamWriter.WriteLine(DateTime.Now);
                streamWriter.WriteLine(playerOne + " " + usesAI);
                streamWriter.WriteLine(BaseColumns.Length);
                foreach (int height in BaseColumns)
                {
                    streamWriter.Write(height + " ");
                }
                streamWriter.WriteLine("");

                streamWriter.WriteLine(curIndex);
                for (int i = 0; i < curIndex; i++)
                {
                    streamWriter.WriteLine($"{i} {moves[i, 0]} {moves[i, 1]}");
                }

                streamWriter.WriteLine();

                streamWriter.Close();

                pauseMoves = true;
                GroupTwo.Visible = true;
                WinningText.Text = $"Player {(playerOne ? "one" : "two")} has won!";
                if (usesAI && !playerOne)
                {
                    WinningText.Text = $"AI has won!";
                }
                return;
            }

            NextTurn();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            if (pauseMoves)
            {
                return;
            }

            toRemove = [moves[curIndex, 0], moves[curIndex, 1]];
            pauseMoves = true;

            simpleTimer = new System.Windows.Forms.Timer();
            simpleTimer.Interval = 1000;
            simpleTimer.Tick += FinishDeleting;
            simpleTimer.Start();

            curIndex = Math.Min(curIndex + 1, moves.Length - 1);
        }

        private void Back_Click(object sender, EventArgs e)
        {
            if (pauseMoves)
            {
                return;
            }

            if (curIndex == 0 && Math.Max(curIndex - 1, 0) == 0)
            {
                return;
            }
            curIndex = Math.Max(curIndex - 1, 0);

            toRemove = [moves[curIndex, 0], -moves[curIndex, 1]];
            pauseMoves = true;

            simpleTimer = new System.Windows.Forms.Timer();
            simpleTimer.Interval = 1000;
            simpleTimer.Tick += FinishDeleting;
            simpleTimer.Start();
        }
    }
}
