﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace nim
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            if (!System.IO.File.Exists(@"output-file.txt"))
            {
                string filePath = Directory.GetCurrentDirectory();

                filePath = Path.Combine(filePath, "output-file.txt");
                StreamWriter write = new StreamWriter(filePath);
                write.Close();
            }

            loadList();
        }

        private void showthis(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            loadList();

            this.Show();
        }

        private void loadList()
        {
            string[] lines = System.IO.File.ReadAllLines(@"output-file.txt");

            int curInt = 0;
            int lost = 0;
            int won = 0;
            while (curInt < lines.Length)
            {
                listBox1.Items.Add(lines[curInt]);

                string[] playerAndAI = lines[curInt + 1].Split(' ');
                
                // if we use AI and we lost
                bool PlayerWon = bool.Parse(playerAndAI[0]);
                bool usedAI = bool.Parse(playerAndAI[1]);
                if (usedAI && !PlayerWon) {
                    lost = lost + 1;
                } else if (usedAI && PlayerWon)
                {
                    won = won + 1;
                }

                curInt = curInt + 4;
                int lineCount = int.Parse(lines[curInt]);
                curInt = lineCount + curInt + 2;
            }
            winAI.Text = "Wins Against AI: " + won;
            AILoss.Text = "Losses Against AI: " + lost;
        }

        private void startGame_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            form.FormClosed += showthis;
            form.usesAI = radioButton1.Checked;
            form.AIStrength = trackBar1.Value;

            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                return;
            }

            string[] lines = System.IO.File.ReadAllLines(@"output-file.txt");

            int curInt = 0;
            bool hasFound = false;
            while (!hasFound)
            {
                if (listBox1.SelectedItem.ToString() == lines[curInt])
                {
                    Form1 form = new Form1();
                    form.Show();
                    form.FormClosed += (s, args) => this.Show();
                    form.setupBlock(curInt);

                    this.Hide();

                    hasFound = true;
                }

                curInt = curInt + 4;
                int lineCount = int.Parse(lines[curInt]);
                curInt = lineCount + curInt + 2;
            }
        }
    }
}
