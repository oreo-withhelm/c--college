﻿namespace nim
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PlayerLabel = new Label();
            box = new Label();
            xBox = new NumericUpDown();
            amountBox = new NumericUpDown();
            actionButton = new Button();
            label1 = new Label();
            label2 = new Label();
            ErrorBox = new Label();
            groupOne = new GroupBox();
            Next = new Button();
            Back = new Button();
            GroupTwo = new GroupBox();
            WinningText = new Label();
            ((System.ComponentModel.ISupportInitialize)xBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)amountBox).BeginInit();
            groupOne.SuspendLayout();
            GroupTwo.SuspendLayout();
            SuspendLayout();
            // 
            // PlayerLabel
            // 
            PlayerLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            PlayerLabel.Location = new Point(39, 33);
            PlayerLabel.Name = "PlayerLabel";
            PlayerLabel.Size = new Size(308, 25);
            PlayerLabel.TabIndex = 0;
            PlayerLabel.Text = "player x";
            PlayerLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // box
            // 
            box.Font = new Font("Consolas", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            box.Location = new Point(39, 70);
            box.Name = "box";
            box.Size = new Size(430, 257);
            box.TabIndex = 1;
            box.Text = "**";
            box.TextAlign = ContentAlignment.BottomLeft;
            // 
            // xBox
            // 
            xBox.Location = new Point(39, 361);
            xBox.Name = "xBox";
            xBox.Size = new Size(74, 23);
            xBox.TabIndex = 3;
            // 
            // amountBox
            // 
            amountBox.Location = new Point(119, 361);
            amountBox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            amountBox.Name = "amountBox";
            amountBox.Size = new Size(74, 23);
            amountBox.TabIndex = 4;
            amountBox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // actionButton
            // 
            actionButton.Location = new Point(199, 361);
            actionButton.Name = "actionButton";
            actionButton.Size = new Size(121, 23);
            actionButton.TabIndex = 5;
            actionButton.Text = "Perform Action";
            actionButton.UseVisualStyleBackColor = true;
            actionButton.Click += actionButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(39, 343);
            label1.Name = "label1";
            label1.Size = new Size(14, 15);
            label1.TabIndex = 6;
            label1.Text = "X";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(119, 343);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 7;
            label2.Text = "Amount";
            // 
            // ErrorBox
            // 
            ErrorBox.AutoSize = true;
            ErrorBox.ForeColor = Color.Red;
            ErrorBox.Location = new Point(39, 70);
            ErrorBox.Name = "ErrorBox";
            ErrorBox.Size = new Size(0, 15);
            ErrorBox.TabIndex = 8;
            // 
            // groupOne
            // 
            groupOne.Controls.Add(Next);
            groupOne.Controls.Add(Back);
            groupOne.Controls.Add(PlayerLabel);
            groupOne.Controls.Add(ErrorBox);
            groupOne.Controls.Add(box);
            groupOne.Controls.Add(actionButton);
            groupOne.Controls.Add(label2);
            groupOne.Controls.Add(xBox);
            groupOne.Controls.Add(label1);
            groupOne.Controls.Add(amountBox);
            groupOne.Location = new Point(64, 24);
            groupOne.Name = "groupOne";
            groupOne.Size = new Size(679, 399);
            groupOne.TabIndex = 9;
            groupOne.TabStop = false;
            // 
            // Next
            // 
            Next.Location = new Point(525, 234);
            Next.Name = "Next";
            Next.Size = new Size(75, 23);
            Next.TabIndex = 10;
            Next.Text = "Next";
            Next.UseVisualStyleBackColor = true;
            Next.Visible = false;
            Next.Click += Next_Click;
            // 
            // Back
            // 
            Back.Location = new Point(444, 234);
            Back.Name = "Back";
            Back.Size = new Size(75, 23);
            Back.TabIndex = 9;
            Back.Text = "Back";
            Back.UseVisualStyleBackColor = true;
            Back.Visible = false;
            Back.Click += Back_Click;
            // 
            // GroupTwo
            // 
            GroupTwo.Controls.Add(WinningText);
            GroupTwo.Location = new Point(57, 24);
            GroupTwo.Name = "GroupTwo";
            GroupTwo.Size = new Size(686, 399);
            GroupTwo.TabIndex = 10;
            GroupTwo.TabStop = false;
            GroupTwo.Visible = false;
            // 
            // WinningText
            // 
            WinningText.AutoSize = true;
            WinningText.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WinningText.Location = new Point(62, 70);
            WinningText.Name = "WinningText";
            WinningText.Size = new Size(157, 32);
            WinningText.TabIndex = 0;
            WinningText.Text = "Winning Text";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(GroupTwo);
            Controls.Add(groupOne);
            Name = "Form1";
            Text = "Game";
            ((System.ComponentModel.ISupportInitialize)xBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)amountBox).EndInit();
            groupOne.ResumeLayout(false);
            groupOne.PerformLayout();
            GroupTwo.ResumeLayout(false);
            GroupTwo.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label PlayerLabel;
        private Label box;
        private NumericUpDown xBox;
        private NumericUpDown amountBox;
        private Button actionButton;
        private Label label1;
        private Label label2;
        private Label ErrorBox;
        private GroupBox groupOne;
        private GroupBox GroupTwo;
        private Label WinningText;
        private Button Next;
        private Button Back;
    }
}
