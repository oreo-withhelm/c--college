﻿namespace nim
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            label1 = new Label();
            button1 = new Button();
            startGame = new Button();
            radioButton1 = new RadioButton();
            trackBar1 = new TrackBar();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            winAI = new Label();
            AILoss = new Label();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(600, 39);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(154, 364);
            listBox1.Sorted = true;
            listBox1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(600, 21);
            label1.Name = "label1";
            label1.Size = new Size(115, 15);
            label1.TabIndex = 1;
            label1.Text = "Load Previous Game";
            // 
            // button1
            // 
            button1.Location = new Point(679, 409);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 2;
            button1.Text = "Load";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // startGame
            // 
            startGame.Location = new Point(77, 109);
            startGame.Name = "startGame";
            startGame.Size = new Size(75, 23);
            startGame.TabIndex = 3;
            startGame.Text = "Start Game";
            startGame.UseVisualStyleBackColor = true;
            startGame.Click += startGame_Click;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(77, 65);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(50, 19);
            radioButton1.TabIndex = 4;
            radioButton1.TabStop = true;
            radioButton1.Text = "vs AI";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // trackBar1
            // 
            trackBar1.LargeChange = 1;
            trackBar1.Location = new Point(176, 65);
            trackBar1.Maximum = 2;
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(160, 45);
            trackBar1.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(176, 47);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 6;
            label2.Text = "Easy";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(239, 47);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 7;
            label3.Text = "Hard";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(294, 47);
            label4.Name = "label4";
            label4.Size = new Size(64, 15);
            label4.TabIndex = 8;
            label4.Text = "Impossible";
            // 
            // winAI
            // 
            winAI.AutoSize = true;
            winAI.Location = new Point(77, 195);
            winAI.Name = "winAI";
            winAI.Size = new Size(128, 15);
            winAI.TabIndex = 9;
            winAI.Text = "Total Wins against AI: 0";
            // 
            // AILoss
            // 
            AILoss.AutoSize = true;
            AILoss.Location = new Point(78, 221);
            AILoss.Name = "AILoss";
            AILoss.Size = new Size(133, 15);
            AILoss.TabIndex = 10;
            AILoss.Text = "Total losses against AI: 0";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(AILoss);
            Controls.Add(winAI);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(trackBar1);
            Controls.Add(radioButton1);
            Controls.Add(startGame);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(listBox1);
            Name = "Form2";
            Text = "Home Page";
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private Label label1;
        private Button button1;
        private Button startGame;
        private RadioButton radioButton1;
        private TrackBar trackBar1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label winAI;
        private Label AILoss;
    }
}