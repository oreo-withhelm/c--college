using System.Drawing.Printing;
using System.Net;

namespace hangman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            MakeLabels();
            DrawHangPost();
        }

        private void Form1_Load(object sender, EventArgs e) { }
        enum BodyParts
        {
            Head,
            Left_Eye,
            Right_Eye,
            Mouth,
            Right_Arm,
            Left_Arm,
            Body,
            Right_Leg,
            Left_Leg,
        }

        string word = "";
        List<Label> labels = new List<Label>();
        int amount = 0;

        private void DrawHangPost()
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics draw = panel1.CreateGraphics();
            Pen pen = new Pen(Color.Brown, 10);

            draw.DrawLine(pen, new Point(130, 218), new Point(130, 5));
            draw.DrawLine(pen, new Point(135, 5), new Point(65, 5));
            draw.DrawLine(pen, new Point(60, 0), new Point(60, 50));
        }

        private void DrawBodyPart(BodyParts bp)
        {
            Graphics draw = panel1.CreateGraphics();
            Pen pen = new Pen(Color.Blue, 2);

            if (bp == BodyParts.Head)
                draw.DrawEllipse(pen, 40, 50, 40, 40);
            else if (bp == BodyParts.Left_Eye)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                draw.FillEllipse(brush, 50, 60, 5, 5);
            }
            else if (bp == BodyParts.Right_Eye)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                draw.FillEllipse(brush, 63, 60, 5, 5);
            }
            else if (bp == BodyParts.Mouth)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                draw.DrawArc(pen, 50, 60, 20, 20, 45, 90);
            }
            else if (bp == BodyParts.Body)
            {
                draw.DrawLine(pen, new Point(60, 90), new Point(60, 170));
            }
            else if (bp == BodyParts.Left_Arm)
            {
                draw.DrawLine(pen, new Point(60, 100), new Point(30, 85));
            }
            else if (bp == BodyParts.Right_Arm)
            {
                draw.DrawLine(pen, new Point(60, 100), new Point(90, 85));
            }
            else if (bp == BodyParts.Left_Leg)
            {
                draw.DrawLine(pen, new Point(60, 170), new Point(30, 190));
            }
            else if (bp == BodyParts.Right_Leg)
            {
                draw.DrawLine(pen, new Point(60, 170), new Point(90, 190));
            }
        }

        string GetRandomWord()
        {
            WebClient wc = new WebClient();
            string wordList = wc.DownloadString("https://gist.githubusercontent.com/cjhveal/3753018/raw/287f964268afbd6dad7b8e6bd7860e4538c1a80a/gistfile1.txt");
            string[] words = wordList.Split("\n");

            Random random = new Random();
            return words[random.Next(0, words.Length - 1)];
        }

        void MakeLabels()
        {
            word = GetRandomWord();

            char[] chars = word.ToCharArray();

            int between = 330 / chars.Length - 1;

            for (int i = 0; i < chars.Length - 1; i++)
            {
                labels.Add(new Label());

                labels[i].Location = new Point((i * between) + 10, 80);
                labels[i].Parent = groupBox2;
                labels[i].Text = "_";
                labels[i].BringToFront();
                labels[i].CreateControl();
            }

            label1.Text = "Word Length: " + (chars.Length - 1).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char letter = textBox1.Text.ToLower().ToCharArray()[0];
            if (!char.IsLetter(letter))
            {
                MessageBox.Show("You can only submit letters!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (word.Contains(letter))
            {
                char[] letters = word.ToCharArray();
                for (int i = 0; i < letters.Length - 1; i++)
                {
                    if (letters[i] == letter)
                    {
                        labels[i].Text = letter.ToString();
                    }
                }

                foreach (Label l in labels)
                {
                    if (l.Text == "_")
                    {
                        return;
                    }
                }

                MessageBox.Show("You have won!", "Congrats!");
            }
            else
            {
                MessageBox.Show("The letter you guessed isnt in the word!", "Sorry");
                label2.Text += " " + letter.ToString() + ",";
                DrawBodyPart((BodyParts)amount);
                amount++;

                if (amount == 9)
                {
                    MessageBox.Show("You lost the game! The word was " + word);
                    ResetGame();
                }
            }
        }

        void ResetGame()
        {
            Graphics g = panel1.CreateGraphics();
            g.Clear(panel1.BackColor);

            GetRandomWord();
            MakeLabels();

            DrawHangPost();

            label2.Text = "Missed: ";
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == word)
            {
                MessageBox.Show("You have won!", "Congrats!");
                ResetGame();
            }
            else
            {
                MessageBox.Show("The word that you guessed is wrong!", "Sorry");
                DrawBodyPart((BodyParts)amount);
                amount++;

                if (amount == 9)
                {
                    MessageBox.Show("You lost the game! The word was " + word);
                    ResetGame();
                }
            }
        }
    }
}
