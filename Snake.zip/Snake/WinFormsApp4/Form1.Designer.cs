﻿namespace WinFormsApp4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            canvas = new PictureBox();
            score = new Label();
            lblScore = new Label();
            GameTimer = new System.Windows.Forms.Timer(components);
            lblGameOver = new Label();
            ((System.ComponentModel.ISupportInitialize)canvas).BeginInit();
            SuspendLayout();
            // 
            // canvas
            // 
            canvas.BackColor = SystemColors.ControlDark;
            canvas.Location = new Point(12, 12);
            canvas.Name = "canvas";
            canvas.Size = new Size(451, 395);
            canvas.TabIndex = 0;
            canvas.TabStop = false;
            canvas.Paint += canvas_Paint;
            // 
            // score
            // 
            score.AutoSize = true;
            score.Font = new Font("Segoe UI", 12F);
            score.Location = new Point(533, 47);
            score.Name = "score";
            score.Size = new Size(52, 21);
            score.TabIndex = 1;
            score.Text = "Score:";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe UI", 12F);
            lblScore.Location = new Point(591, 47);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(0, 21);
            lblScore.TabIndex = 2;
            // 
            // lblGameOver
            // 
            lblGameOver.AutoSize = true;
            lblGameOver.Font = new Font("Segoe UI", 20F);
            lblGameOver.Location = new Point(68, 134);
            lblGameOver.Name = "lblGameOver";
            lblGameOver.Size = new Size(90, 37);
            lblGameOver.TabIndex = 3;
            lblGameOver.Text = "label1";
            lblGameOver.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblGameOver);
            Controls.Add(lblScore);
            Controls.Add(score);
            Controls.Add(canvas);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            KeyUp += Form1_KeyUp;
            ((System.ComponentModel.ISupportInitialize)canvas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox canvas;
        private Label score;
        private Label lblScore;
        private System.Windows.Forms.Timer GameTimer;
        private Label lblGameOver;
    }
}
