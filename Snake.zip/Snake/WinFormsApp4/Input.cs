﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp4
{
    internal class Input
    {
        public static Hashtable inputs = new Hashtable();

        public static bool KeyPressed(Keys key)
        {
            if (inputs[key] == null)
            {
                return false;
            }

            return (bool) inputs[key];
        }

        public static void ChangeState(Keys key, bool state)
        {
            inputs[key] = state;
        }
    }
}
