using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        Graphics draw;
        public Form1()
        {
            InitializeComponent();

            draw = panel1.CreateGraphics();
            panel1.MouseDown += panel1_MouseDown;
            panel1.MouseUp += panel1_MouseUp;
            panel1.MouseMove += panel1_MouseMouse;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        bool canPaint = false;
        int? prevX;
        int? prevY;
        string shape = "";

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            canPaint = true;

            if (shape == "square")
            {
                SolidBrush s = new SolidBrush(toolStripButton1.ForeColor);
                draw.FillRectangle(s, e.X, e.Y, int.Parse(toolStripTextBox1.Text), int.Parse(toolStripTextBox1.Text));
                shape = "";
            }
            else if (shape == "rectangle")
            {
                SolidBrush s = new SolidBrush(toolStripButton1.ForeColor);
                draw.FillRectangle(s, e.X, e.Y, int.Parse(toolStripTextBox1.Text) * 2, int.Parse(toolStripTextBox1.Text));
                shape = "";
            }
            else if (shape == "circle")
            {
                SolidBrush s = new SolidBrush(toolStripButton1.ForeColor);
                draw.FillEllipse(s, e.X, e.Y, int.Parse(toolStripTextBox1.Text), int.Parse(toolStripTextBox1.Text));
                shape = "";
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            canPaint = false;
            prevX = null;
            prevY = null;
        }

        private void panel1_MouseMouse(object sender, MouseEventArgs e)
        {
            if (!canPaint)
            {
                return;
            }

            Pen pen = new Pen(toolStripButton1.ForeColor, (int)numericUpDown1.Value);
            draw.DrawLine(pen, new Point(prevX ?? e.X, prevY ?? e.Y), new Point(e.X, e.Y));
            prevX = e.X;
            prevY = e.Y;
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                toolStripButton1.ForeColor = cd.Color;
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            draw.Clear(panel1.BackColor);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                toolStripButton3.ForeColor = cd.Color;
                panel1.BackColor = cd.Color;
            }
        }

        private void squareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shape = "square";
        }

        private void rectangleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shape = "rectangle";
        }

        private void circleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shape = "circle";
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void panel1_DragDrop(object sender, DragEventArgs e)
        {
            string[] imagePaths = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string path in imagePaths)
            {
                draw.DrawImage(Image.FromFile(path), new Point(0, 0));
            }
        }
    }
}
